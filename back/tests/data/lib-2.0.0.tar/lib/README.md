# Hello

A new C++ project.

## Getting Started

This project is a starting point for a C++ project.

A few helpful commands to get you started if this is your first time using c3pm:

### Building your project
```shell
$ ctpm build
```

### Add a package
```shell
$ ctpm add <package>
```

### Publishing your project
```shell
$ ctpm publish
```

For help getting started with c3pm, view our
[online documentation](https://docs.c3pm.io/), which offers tutorials, samples and
a list of all available commands.
