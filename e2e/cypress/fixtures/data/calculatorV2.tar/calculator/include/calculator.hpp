#pragma once

void hello();